# 🎬 YouTube Factory

Turn **any topic** into a finished, narrated, real-footage 1080p video — with one command.

```bash
python scripts/make_video.py "How Nokia lost the smartphone war"
```

> **Runs fully offline** out of the box: macOS built-in voice + real Creative-Commons
> footage from Wikimedia. Add API keys to upgrade the script and voice to studio quality.

## What it does
For a topic it: writes a storyboard → narrates it → fetches **real HD video clips** that
match each beat → cuts them with crossfades, a cinematic grade, 2.39 letterbox,
lower-third captions, a music bed, and broadcast loudness (−16 LUFS) → outputs an `.mp4`.

## Quick start
```bash
cd youtube-factory
./bootstrap.sh                       # ffmpeg + venv + deps + .env
source .venv/bin/activate
python scripts/make_video.py "Your topic here"
# -> output/videos/<slug>.mp4
```
See **[SETUP.md](SETUP.md)** for a full walkthrough (and which API keys raise quality).

## Two ways to run
```bash
python scripts/make_video.py "Why Blockbuster turned down Netflix"   # one-shot
python -m youtube_factory make "Why Blockbuster turned down Netflix" # package CLI
```


## Quality tiers (all optional, set in `.env`)
| Add | Effect |
|-----|--------|
| `OPENAI_API_KEY` | LLM writes the script + picks footage keywords (else offline template) |
| `ELEVENLABS_API_KEY` + `TTS_PROVIDER=elevenlabs` | natural human voice (biggest jump) |
| `TTS_PROVIDER=openai` | good neural voice via OpenAI `tts-1-hd` |
| `YOUTUBE_CLIENT_SECRETS` | auto-upload / scheduling |

Default `TTS_PROVIDER=say` uses the free macOS voice (softened); `mock` = silent (tests).

## Scaling to a "factory"
- Each video is one `make` call — script it into a loop or cron for a content calendar.
- `config/channels.yaml` + the `publishing/` + `planning/` modules support multi-channel
  scheduling and YouTube uploads when you add OAuth creds.

## ⚠️ Reality checks
- **YouTube monetization** penalizes mass-produced/repetitive content — add genuine value.
- Footage is free/CC (great atmospheric b-roll, not exact-match). Paid stock/AI video for exact shots.
- The free macOS voice is clear but not fully human — ElevenLabs/OpenAI fixes that.

## Tests
```bash
pytest -q          # offline, fast (no keys / ffmpeg / network needed)
```

## Project layout
```
youtube_factory/
  studio/                # the production pipeline (topic -> mp4)
    storyboard.py        #   topic -> beats (LLM or offline template)
    voice.py             #   narration: elevenlabs | openai | say | mock
    footage.py           #   real HD clips from Wikimedia Commons (cached)
    compose.py           #   overlays, graded clips, music
    metadata.py          #   YouTube title/description/tags from the storyboard
    render.py            #   orchestrates + crossfades + masters audio
  steps/                 # ideation (titles) + thumbnail generation
  config.py models.py utils.py
  pipeline.py            # channel layer: plan -> render (studio) -> publish
  cli.py                 # `python -m youtube_factory make "..."`
  publishing/ planning/  # YouTube upload + content calendar
scripts/make_video.py    # thin CLI wrapper
config/channels.yaml     # multi-channel definitions
tests/                   # offline tests
```

## Make a portable zip
```bash
./make_zip.sh            # excludes .venv, output, caches -> youtube-factory.zip
```


