#!/usr/bin/env bash
# Create a small, portable zip of the project (excludes venv, caches, generated media).
set -euo pipefail
cd "$(dirname "$0")"
NAME="youtube-factory.zip"
rm -f "$NAME"
zip -r "$NAME" . \
  -x '*.venv*' \
  -x '*/output/*' -x 'output/*' \
  -x '*/__pycache__/*' \
  -x '*.pyc' \
  -x '*.pytest_cache*' \
  -x '*.idea*' \
  -x '*.git/*' \
  -x '*.env' \
  -x '*.mp4' -x '*.webm' -x '*.ogv' >/dev/null
echo "✅ Created $NAME ($(du -h "$NAME" | cut -f1))"

