"""Make a video from a topic — thin wrapper around the studio pipeline.

Usage:
    python scripts/make_video.py "How Nokia lost the smartphone war"
    python scripts/make_video.py            # uses a default demo topic

Runs fully offline (macOS voice + Wikimedia footage). Add OPENAI_API_KEY and/or
ELEVENLABS_API_KEY to .env to upgrade the script and the voice.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from youtube_factory.studio import produce_video  # noqa: E402

DEFAULT_TOPIC = "How a small YouTube channel grew from zero to its first viral video"


def main() -> int:
    topic = " ".join(sys.argv[1:]).strip() or DEFAULT_TOPIC
    produce_video(topic, log=print)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

