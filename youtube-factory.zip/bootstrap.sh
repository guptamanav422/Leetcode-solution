#!/usr/bin/env bash
# One-command setup for a fresh machine.
#   ./bootstrap.sh
set -euo pipefail
cd "$(dirname "$0")"

echo "==> Checking ffmpeg…"
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "    ffmpeg not found."
  if command -v brew >/dev/null 2>&1; then
    echo "    Installing with Homebrew…"; brew install ffmpeg
  else
    echo "    Please install ffmpeg (macOS: brew install ffmpeg; Ubuntu: sudo apt install ffmpeg)"
    exit 1
  fi
fi

echo "==> Creating virtualenv (.venv)…"
python3 -m venv .venv
source .venv/bin/activate

echo "==> Installing dependencies…"
pip install -q --upgrade pip
pip install -q -r requirements.txt

if [ ! -f .env ]; then
  cp .env.example .env
  echo "==> Created .env (edit it to add API keys; optional)."
fi

echo ""
echo "✅ Setup complete. Try it:"
echo "   source .venv/bin/activate"
echo "   python scripts/make_video.py \"How Nokia lost the smartphone war\""

