"""Offline tests for the channel/factory orchestration layer.

The heavy video render (ffmpeg + network footage) is mocked so these stay fast
and run anywhere; the studio's own logic is covered in test_studio.py.
"""
import json
from pathlib import Path

import pytest

from youtube_factory import pipeline
from youtube_factory.config import ChannelConfig
from youtube_factory.models import PipelineStatus
from youtube_factory.planning.calendar import ContentCalendar
from youtube_factory.publishing.scheduler import upcoming_slots
from youtube_factory.steps import ideation
from youtube_factory.studio import build_metadata, build_storyboard


@pytest.fixture
def channel():
    return ChannelConfig(
        id="test-ch", name="Test Channel",
        niche="business collapse case studies", target_minutes=8,
        cadence_per_week=2, upload_days=["Tuesday", "Friday"],
        keywords_seed=["bankruptcy", "scandal", "case study"],
    )


@pytest.fixture(autouse=True)
def _isolate(tmp_path, monkeypatch):
    monkeypatch.setenv("OUTPUT_DIR", str(tmp_path / "out"))
    monkeypatch.setenv("OPENAI_API_KEY", "")
    monkeypatch.setenv("TTS_PROVIDER", "mock")
    from youtube_factory import config
    config.get_settings.cache_clear()
    yield


def test_ideation_is_deterministic(channel):
    a = ideation.generate_ideas(channel, 3)
    b = ideation.generate_ideas(channel, 3)
    assert len(a) == 3
    assert [i.title for i in a] == [i.title for i in b]
    assert all(i.title for i in a)


def test_scheduler_respects_days_and_cadence(channel):
    slots = upcoming_slots(channel, 4)
    assert len(slots) == 4
    assert all(s.weekday() in (1, 4) for s in slots)
    assert slots == sorted(slots)


def test_metadata_from_storyboard(channel):
    sb = build_storyboard("Why Kodak failed to go digital")
    meta = build_metadata(sb, channel)
    assert meta.title
    assert len(meta.tags) > 0
    assert meta.privacy_status == "private"
    assert "Subscribe" in meta.description


def test_plan_channel_reserves_slots(channel, tmp_path):
    cal = ContentCalendar(tmp_path / "calendar.json")
    projects = pipeline.plan_channel(channel, 3, cal)
    assert len(projects) == 3
    assert all(p.scheduled_for is not None for p in projects)
    assert cal.summary()["total"] == 3


def test_full_pipeline_uses_studio(channel, tmp_path, monkeypatch):
    """run_full should render via the studio and reach READY/PUBLISHED."""
    def fake_render(topic, out_path=None, settings=None, storyboard=None, log=print):
        p = Path(out_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"\x00\x00")
        return p

    monkeypatch.setattr(pipeline, "produce_video", fake_render)
    cal = ContentCalendar(tmp_path / "calendar.json")
    projects = pipeline.run_full(channel, count=2, do_publish=True, calendar=cal)

    assert len(projects) == 2
    for p in projects:
        assert p.status in (PipelineStatus.READY, PipelineStatus.PUBLISHED)
        assert p.metadata is not None
        assert Path(p.video_path).exists()
        assert Path(p.thumbnail_path).exists()
    data = json.loads((tmp_path / "calendar.json").read_text())
    assert len(data) == 2

