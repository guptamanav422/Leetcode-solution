"""Offline tests for the studio storyboard builder (no network / ffmpeg / keys)."""
from youtube_factory.studio.storyboard import (
    SAFE_FOOTAGE,
    Storyboard,
    build_storyboard,
    keywords,
    offline_storyboard,
)


def test_keywords_drops_stopwords():
    kw = keywords("How the company that lost everything came back")
    assert "the" not in kw and "how" not in kw
    assert "company" in kw


def test_offline_storyboard_shape():
    sb = offline_storyboard("How Kodak missed digital photography")
    assert isinstance(sb, Storyboard)
    assert 6 <= len(sb.beats) <= 10
    assert sb.word_count > 40
    for beat in sb.beats:
        assert beat.narration.strip()
        assert beat.queries  # always has footage queries
        # safe generic fallbacks are appended so footage always resolves
        assert any(q in beat.queries for q in SAFE_FOOTAGE)


def test_build_storyboard_offline_when_no_llm(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "")
    from youtube_factory import config
    config.get_settings.cache_clear()
    sb = build_storyboard("Why Blockbuster turned down Netflix")
    assert sb.title
    assert len(sb.beats) >= 6


def test_storyboard_is_deterministic():
    a = offline_storyboard("same topic")
    b = offline_storyboard("same topic")
    assert [x.narration for x in a.beats] == [x.narration for x in b.beats]

