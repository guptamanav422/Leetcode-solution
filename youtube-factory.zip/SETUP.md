# Setup Guide — YouTube Factory

Everything you need to run this on a fresh (personal) laptop.

## TL;DR
```bash
# 1. unzip, then:
cd youtube-factory
./bootstrap.sh                 # installs ffmpeg (via brew), venv, deps, .env

# 2. make a video about ANY topic (runs offline, no keys needed):
source .venv/bin/activate
python scripts/make_video.py "How Nokia lost the smartphone war"
# -> output/videos/how-nokia-lost-the-smartphone-war.mp4
```

## Requirements
- **Python 3.10+**
- **ffmpeg** (`brew install ffmpeg` on macOS, `sudo apt install ffmpeg` on Linux)
- Internet (to fetch free Wikimedia footage)
- macOS gives you a free built-in voice (`say`). On Linux, set a real voice key (below) or it falls back to a silent track.

## Manual setup (if you skip bootstrap.sh)
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## Coding assistant on your laptop
This project was built with **GitHub Copilot** (not a Claude subscription).
Install the **GitHub Copilot** plugin in VS Code / PyCharm and sign in with GitHub.
Copilot **Free** is enough to keep iterating; **Pro ($10/mo)** removes limits and unlocks stronger models. You do **not** need any separate AI subscription to keep working on this code.

## Going from "good" to "studio quality" — which keys
All optional; add to `.env`. Biggest quality jumps first:

| Want | Add to `.env` | Notes |
|------|---------------|-------|
| **Human voice** (biggest jump) | `ELEVENLABS_API_KEY=...` + `TTS_PROVIDER=elevenlabs` | ~$22/mo Creator plan. Optional `ELEVENLABS_VOICE_ID`. |
| Good voice (cheaper) | `OPENAI_API_KEY=...` + `TTS_PROVIDER=openai` | Uses `tts-1-hd`. |
| **Written script/research** | `OPENAI_API_KEY=...` | LLM writes the storyboard; else an offline template is used. |
| Auto-upload to YouTube | `YOUTUBE_CLIENT_SECRETS=...` | OAuth JSON from Google Cloud Console. |

> ⚠️ Note: a corporate/proxy network may block these APIs. Run on a personal network if calls fail.

## Commands
```bash
# One-shot video from a topic (recommended):
python scripts/make_video.py "Your topic here"

# Same via the package CLI:
python -m youtube_factory make "Your topic here"

# Run the test suite (offline, fast):
pytest -q
```

## Make a small zip to move the project
```bash
./make_zip.sh        # excludes .venv, output, caches -> youtube-factory.zip
```

## What you get
`output/videos/<slug>.mp4` — a 1080p narrated video with real footage,
cinematic grade + letterbox, captions, crossfades, music bed, and broadcast
loudness (−16 LUFS). Footage is cached in `output/footage_cache/` for fast re-runs.

