"""Environment + channel configuration loading."""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Dict, List

import yaml
from dotenv import load_dotenv

from .models import ChannelConfig

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class Settings:
    """Reads configuration from environment variables (.env)."""

    def __init__(self) -> None:
        self.openai_api_key = os.getenv("OPENAI_API_KEY", "").strip()
        self.openai_model = os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip()
        # Voice: elevenlabs | openai | say (macOS, default) | mock
        self.tts_provider = os.getenv("TTS_PROVIDER", "say").strip().lower()
        self.tts_voice = os.getenv("TTS_VOICE", "onyx").strip()
        self.elevenlabs_api_key = os.getenv("ELEVENLABS_API_KEY", "").strip()
        self.elevenlabs_voice_id = os.getenv("ELEVENLABS_VOICE_ID", "").strip()
        self.visuals_provider = os.getenv("VISUALS_PROVIDER", "mock").strip().lower()
        self.pexels_api_key = os.getenv("PEXELS_API_KEY", "").strip()
        self.youtube_client_secrets = os.getenv(
            "YOUTUBE_CLIENT_SECRETS", "secrets/youtube_client_secret.json"
        ).strip()
        self.youtube_token_store = os.getenv(
            "YOUTUBE_TOKEN_STORE", "secrets/youtube_token.json"
        ).strip()
        self.output_dir = Path(os.getenv("OUTPUT_DIR", "output"))

    @property
    def has_llm(self) -> bool:
        return bool(self.openai_api_key)

    @property
    def has_youtube(self) -> bool:
        return Path(self.youtube_client_secrets).exists()


@lru_cache
def get_settings() -> Settings:
    return Settings()


def load_channels(path: str | Path = "config/channels.yaml") -> List[ChannelConfig]:
    p = Path(path)
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return [ChannelConfig(**c) for c in data.get("channels", [])]


def channels_by_id(path: str | Path = "config/channels.yaml") -> Dict[str, ChannelConfig]:
    return {c.id: c for c in load_channels(path)}


def get_channel(channel_id: str, path: str | Path = "config/channels.yaml") -> ChannelConfig:
    mapping = channels_by_id(path)
    if channel_id not in mapping:
        raise KeyError(
            f"Channel '{channel_id}' not found. Available: {', '.join(mapping)}"
        )
    return mapping[channel_id]

