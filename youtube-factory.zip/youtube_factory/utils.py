"""Shared helpers: slugify, file IO, ffmpeg detection, and an LLM client wrapper."""
from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from .config import get_settings

logger = logging.getLogger("youtube_factory")


def setup_logging(verbose: bool = False) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )


def slugify(text: str, max_len: int = 60) -> str:
    text = re.sub(r"[^\w\s-]", "", text.lower()).strip()
    text = re.sub(r"[\s_-]+", "-", text)
    return text[:max_len].strip("-") or "untitled"


def ffmpeg_available() -> bool:
    return shutil.which("ffmpeg") is not None


def run_ffmpeg(args: list[str]) -> bool:
    """Run ffmpeg with the given args; return True on success."""
    if not ffmpeg_available():
        logger.warning("ffmpeg not found on PATH; skipping render.")
        return False
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *args]
    logger.debug("Running: %s", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error("ffmpeg failed: %s", result.stderr.strip())
        return False
    return True


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if hasattr(obj, "model_dump_json"):
        path.write_text(obj.model_dump_json(indent=2), encoding="utf-8")
    else:
        path.write_text(json.dumps(obj, indent=2, default=str), encoding="utf-8")


class LLMClient:
    """Thin wrapper over OpenAI chat completions returning parsed JSON."""

    def __init__(self) -> None:
        from openai import OpenAI  # imported lazily so mock mode needs no install

        settings = get_settings()
        self._client = OpenAI(api_key=settings.openai_api_key)
        self._model = settings.openai_model

    def complete_json(self, system: str, prompt: str) -> dict:
        resp = self._client.chat.completions.create(
            model=self._model,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            temperature=0.8,
        )
        return json.loads(resp.choices[0].message.content)


def get_llm() -> Optional[LLMClient]:
    """Return an LLMClient if an API key is configured, else None (mock mode)."""
    if not get_settings().has_llm:
        return None
    try:
        return LLMClient()
    except Exception as exc:  # pragma: no cover - depends on optional dep
        logger.warning("LLM unavailable (%s); falling back to mock mode.", exc)
        return None

