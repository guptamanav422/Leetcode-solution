"""Compose: cinematic primitives — caption overlays, graded clips, music bed."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from .ffmpeg_utils import probe_duration, run

W, H, FPS, BAR = 1920, 1080, 30, 140
ACCENT = (236, 236, 240)
TITLE_ACCENT = (224, 188, 116)


def _font(size: int, bold: bool = True) -> ImageFont.FreeTypeFont:
    cands = (["/System/Library/Fonts/Supplemental/Arial Bold.ttf",
              "/System/Library/Fonts/Helvetica.ttc", "DejaVuSans-Bold.ttf"] if bold else
             ["/System/Library/Fonts/Supplemental/Arial.ttf",
              "/System/Library/Fonts/Helvetica.ttc", "DejaVuSans.ttf"])
    for n in cands:
        try:
            return ImageFont.truetype(n, size)
        except OSError:
            continue
    return ImageFont.load_default()


def make_overlay(caption: str, out: Path, title: bool = False, accent=ACCENT) -> None:
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    d.rectangle([0, 0, W, BAR], fill=(0, 0, 0, 255))
    d.rectangle([0, H - BAR, W, H], fill=(0, 0, 0, 255))
    if not caption:
        ov.save(out)
        return
    if title:
        f = _font(120, True)
        tw = d.textlength(caption, font=f)
        x, y = (W - tw) / 2, H * 0.42
        d.text((x + 3, y + 3), caption, font=f, fill=(0, 0, 0, 220))
        d.text((x, y), caption, font=f, fill=(244, 240, 230, 255))
        d.rectangle([x, y + 150, x + tw, y + 158], fill=(*TITLE_ACCENT, 255))
    else:
        gh = 220
        for i in range(gh):
            a = int(150 * (i / gh))
            d.line([(0, H - BAR - gh + i), (W, H - BAR - gh + i)], fill=(0, 0, 0, a))
        f = _font(54, False)
        tw = d.textlength(caption, font=f)
        x, y = (W - tw) / 2, H - BAR - 92
        d.text((x + 2, y + 2), caption, font=f, fill=(0, 0, 0, 200))
        d.text((x, y), caption, font=f, fill=(*accent, 255))
    ov.save(out)


def make_clip(src: Path, overlay: Path, out: Path, dur: float, start: float | None = None) -> None:
    srcdur = probe_duration(src)
    if start is None:
        start = max(0.0, (srcdur - dur) / 2) if srcdur > dur + 0.5 else 0.0
    else:
        start = max(0.0, min(start, max(0.0, srcdur - dur)))
    vf = (f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
          f"fps={FPS},eq=contrast=1.05:saturation=1.08:gamma=0.99,vignette=PI/5[bg];"
          f"[bg][1:v]overlay=0:0:shortest=1,format=yuv420p[v]")
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
         "-stream_loop", "3", "-ss", f"{start:.2f}", "-t", f"{dur:.3f}", "-i", str(src),
         "-loop", "1", "-t", f"{dur:.3f}", "-i", str(overlay),
         "-filter_complex", vf, "-map", "[v]", "-an",
         "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
         "-r", str(FPS), str(out)])


def make_color_clip(overlay: Path, out: Path, dur: float) -> None:
    """Fallback graded card if no footage was found for a beat."""
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
         "-f", "lavfi", "-i", f"color=c=0x0e1018:s={W}x{H}:r={FPS}:d={dur:.3f}",
         "-loop", "1", "-t", f"{dur:.3f}", "-i", str(overlay),
         "-filter_complex",
         "[0:v]vignette=PI/5[bg];[bg][1:v]overlay=0:0:shortest=1,format=yuv420p[v]",
         "-map", "[v]", "-an", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
         "-pix_fmt", "yuv420p", str(out)])


def render_music(total: float, out: Path) -> None:
    fc = (f"sine=frequency=174.61:duration={total}[a0];"
          f"sine=frequency=261.63:duration={total}[a1];"
          f"sine=frequency=220:duration={total}[a2];"
          f"[a0][a1][a2]amix=inputs=3:normalize=1,tremolo=f=0.16:d=0.55,"
          f"aecho=0.8:0.85:130:0.4,lowpass=f=640,"
          f"afade=t=in:st=0:d=3,afade=t=out:st={max(0.0, total - 3.5):.2f}:d=3.5[m]")
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "lavfi",
         "-i", "anullsrc", "-filter_complex", fc, "-map", "[m]", "-t", f"{total:.3f}",
         "-ar", "44100", "-ac", "2", str(out)])

