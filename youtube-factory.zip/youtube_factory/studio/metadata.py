"""Build YouTube metadata (title/description/tags) from a storyboard."""
from __future__ import annotations

from ..models import VideoMetadata
from .storyboard import Storyboard, keywords


def build_metadata(storyboard: Storyboard, channel=None,
                   privacy_status: str = "private") -> VideoMetadata:
    beats = storyboard.beats
    hook = beats[0].narration.strip() if beats else storyboard.title

    lines = [hook, "", f"In this video: {storyboard.title}.", "", "In this story:"]
    for b in beats:
        if b.caption:
            lines.append(f"• {b.caption}")
    lines += ["", "Subscribe for more stories like this."]

    seed = keywords(storyboard.title, 6)
    if channel is not None:
        seed += list(getattr(channel, "keywords_seed", []) or [])
    footage = [q for b in beats for q in b.queries]
    tags = list(dict.fromkeys(seed + footage))[:15]

    return VideoMetadata(
        title=storyboard.title[:100],
        description="\n".join(lines)[:4900],
        tags=tags,
        privacy_status=privacy_status,
    )

