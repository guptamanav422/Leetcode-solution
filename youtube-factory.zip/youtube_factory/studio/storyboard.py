"""Storyboard: turn a topic string into an ordered list of narrated beats.

With an LLM (OpenAI) it writes a tight, retention-optimised script and chooses
footage keywords. Without one, a deterministic offline template keeps the whole
pipeline working so you can preview structure and motion.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import List, Optional

# Generic footage terms that reliably exist in HD on Wikimedia Commons.
SAFE_FOOTAGE = ["city traffic night", "city night timelapse", "clouds timelapse",
                "ocean waves", "sunrise timelapse", "people walking street"]

_STOPWORDS = {"the", "a", "an", "of", "and", "or", "to", "in", "on", "for", "with",
              "how", "why", "what", "is", "was", "did", "that", "this", "at", "by"}


@dataclass
class Beat:
    narration: str
    caption: str
    queries: List[str]
    speaker: str = "narrator"


@dataclass
class Storyboard:
    title: str
    beats: List[Beat] = field(default_factory=list)

    @property
    def word_count(self) -> int:
        return sum(len(b.narration.split()) for b in self.beats)


def keywords(topic: str, n: int = 4) -> List[str]:
    words = [w for w in re.findall(r"[A-Za-z0-9']+", topic.lower()) if w not in _STOPWORDS]
    return words[:n] or [topic]


def _queries_for(topic: str, extra: str) -> List[str]:
    kw = keywords(topic)
    base = " ".join(kw[:2]) if kw else topic
    return [f"{base} {extra}".strip(), base, extra] + SAFE_FOOTAGE[:2]


def offline_storyboard(topic: str) -> Storyboard:
    """A coherent 8-beat narrated arc built from templates (no LLM required)."""
    t = topic.strip().rstrip(".")
    title = t[:70]
    beats = [
        Beat(f"Here's something most people never realised about {t}.",
             title, _queries_for(t, "establishing wide")),
        Beat(f"It didn't begin with a grand plan. {t.capitalize()} started small, "
             f"almost unnoticed.", "How it began", _queries_for(t, "origin early")),
        Beat("But beneath the surface, the pressure was already building.",
             "The pressure builds", _queries_for(t, "tension dark")),
        Beat("Then came the moment that changed everything.",
             "The turning point", _queries_for(t, "turning point dramatic")),
        Beat("The decisions made next would echo for years.",
             "The decision", _queries_for(t, "decision people")),
        Beat("And when it finally unravelled, almost no one was ready.",
             "The unravelling", _queries_for(t, "fast motion crowd")),
        Beat(f"So what can {t} teach the rest of us?",
             "The lesson", _queries_for(t, "reflective sunrise")),
        Beat("Because in the end, every story like this starts the same way — "
             "with a single decision.", title.upper(), _queries_for(t, "city lights hopeful")),
    ]
    return Storyboard(title=title, beats=beats)


def _llm_storyboard(topic: str, client, model: str) -> Optional[Storyboard]:
    system = ("You are a YouTube scriptwriter for high-retention, factual case-study "
              "videos. You return ONLY valid JSON.")
    prompt = (
        f"Write a tight narrated script about: \"{topic}\".\n"
        "Return JSON: {\"title\": str, \"beats\": [{\"narration\": str, "
        "\"caption\": str, \"footage_keywords\": [str, str, str]}]}.\n"
        "Rules: 7-9 beats forming a narrative arc (hook, context, rise, turning "
        "point, climax, aftermath, lesson, payoff). Each narration is 1-2 spoken "
        "sentences. Captions are <= 5 words. footage_keywords are concrete, "
        "filmable nouns/scenes (e.g. 'city skyline night', 'server room')."
    )
    resp = client.chat.completions.create(
        model=model, response_format={"type": "json_object"},
        messages=[{"role": "system", "content": system},
                  {"role": "user", "content": prompt}], temperature=0.8)
    data = json.loads(resp.choices[0].message.content)
    beats = []
    for b in data.get("beats", []):
        kws = b.get("footage_keywords") or []
        beats.append(Beat(
            narration=b.get("narration", "").strip(),
            caption=(b.get("caption") or "").strip()[:40],
            queries=[k for k in kws if k][:3] + SAFE_FOOTAGE[:2]))
    if not beats:
        return None
    return Storyboard(title=(data.get("title") or topic)[:70], beats=beats)


def build_storyboard(topic: str, settings=None, log=print) -> Storyboard:
    """LLM script if a key is configured, else a deterministic offline arc."""
    try:
        from ..config import get_settings
        settings = settings or get_settings()
    except Exception:
        settings = None

    if settings is not None and getattr(settings, "has_llm", False):
        try:
            from openai import OpenAI
            client = OpenAI(api_key=settings.openai_api_key)
            sb = _llm_storyboard(topic, client, settings.openai_model)
            if sb:
                log(f"📝 Script: LLM ({settings.openai_model}), {len(sb.beats)} beats")
                return sb
        except Exception as exc:  # pragma: no cover - network/optional dep
            log(f"⚠️  LLM scripting failed ({exc}); using offline template.")
    log("📝 Script: offline template (set OPENAI_API_KEY for a written script)")
    return offline_storyboard(topic)

