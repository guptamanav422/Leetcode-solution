"""The Studio: turn any topic into a finished, narrated, real-footage video.

This is the production pipeline. With no API keys it runs fully offline
(macOS `say` voice + Wikimedia footage). Add OPENAI_API_KEY / ELEVENLABS_API_KEY
to upgrade the script and the voice to studio quality.
"""
from .metadata import build_metadata
from .render import produce_video
from .storyboard import Beat, Storyboard, build_storyboard

__all__ = ["produce_video", "build_storyboard", "build_metadata", "Storyboard", "Beat"]

