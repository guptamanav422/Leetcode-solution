"""Footage: fetch real HD video clips from Wikimedia Commons (no API key).

Wikimedia is the one media host that downloads reliably here (incl. behind
corporate proxies). Clips are cached so re-runs are fast.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import List, Optional

import requests

from .ffmpeg_utils import video_dims
from .storyboard import SAFE_FOOTAGE

UA = {"User-Agent": "youtube-factory/1.0 (educational; contact local)"}
_MAX_BYTES = 140 * 1024 * 1024


def commons_videos(sess: requests.Session, query: str, limit: int = 6) -> List[str]:
    r = sess.get("https://commons.wikimedia.org/w/api.php", params={
        "action": "query", "generator": "search",
        "gsrsearch": f"filetype:video {query}", "gsrnamespace": 6, "gsrlimit": limit,
        "prop": "imageinfo", "iiprop": "url|size|mime", "format": "json"}, timeout=30)
    r.raise_for_status()
    pages = (r.json().get("query", {}) or {}).get("pages", {})
    urls = []
    for p in sorted(pages.values(), key=lambda x: x.get("index", 99)):
        ii = (p.get("imageinfo") or [{}])[0]
        if ii.get("mime") in ("video/webm", "application/ogg") and (ii.get("width") or 0) >= 1280:
            urls.append(ii["url"])
    return urls


def _valid(path: Path) -> bool:
    if not path.exists() or path.stat().st_size < 300_000:
        return False
    w, d = video_dims(path)
    return w >= 640 and d >= 2.0


def fetch_clip(queries: List[str], cache_dir: Path, idx: int,
               sess: Optional[requests.Session] = None) -> Optional[Path]:
    cache_dir.mkdir(parents=True, exist_ok=True)
    for c in sorted(cache_dir.glob(f"scene{idx:02d}.*")):
        if _valid(c):
            return c
        c.unlink(missing_ok=True)

    sess = sess or requests.Session()
    sess.headers.update(UA)
    for q in list(queries) + SAFE_FOOTAGE:
        urls: List[str] = []
        for attempt in range(2):
            try:
                urls = commons_videos(sess, q)
                break
            except Exception:
                time.sleep(1.5)
        for url in urls[:4]:
            ext = os.path.splitext(url)[1] or ".webm"
            dst = cache_dir / f"scene{idx:02d}{ext}"
            try:
                with sess.get(url, timeout=180, stream=True) as resp:
                    if resp.status_code != 200:
                        continue
                    size = int(resp.headers.get("Content-Length", 0))
                    if size and size > _MAX_BYTES:
                        continue
                    with open(dst, "wb") as fh:
                        for chunk in resp.iter_content(1 << 16):
                            fh.write(chunk)
                if _valid(dst):
                    return dst
                dst.unlink(missing_ok=True)
            except Exception:
                dst.unlink(missing_ok=True)
        time.sleep(0.4)
    return None

