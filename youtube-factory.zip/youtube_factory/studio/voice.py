"""Voice: synthesize narration. Auto-selects the best available provider.

Priority (configurable via TTS_PROVIDER):
  elevenlabs  -> most natural (needs ELEVENLABS_API_KEY)
  openai      -> very good       (needs OPENAI_API_KEY)
  say         -> macOS built-in voice, softened (offline, default on macOS)
  mock        -> silent track sized to the words (offline, any OS — for tests)
"""
from __future__ import annotations

import platform
import shutil
import wave
from pathlib import Path
from typing import Tuple

from .ffmpeg_utils import probe_duration, run

# Soft mastering for the macOS `say` voice (warm, de-essed, gentle room).
_SOFT_AF = ("highpass=f=85,equalizer=f=240:t=q:w=1:g=2.5,equalizer=f=6500:t=q:w=2:g=-4,"
            "lowpass=f=9500,acompressor=threshold=-20dB:ratio=3:attack=15:release=260,"
            "aecho=0.8:0.9:55:0.2,volume=2.2")

_SAY_VOICE = {"narrator": ("Samantha", 168), "male": ("Rishi", 172), "female": ("Karen", 176)}
_ELEVEN_DEFAULT = "21m00Tcm4TlvDq8ikWAM"  # "Rachel"


def _pick_provider(settings) -> str:
    p = (getattr(settings, "tts_provider", "") or "").lower()
    if p in ("elevenlabs", "openai", "say", "mock"):
        # validate availability, else fall through to auto
        if p == "elevenlabs" and getattr(settings, "elevenlabs_api_key", ""):
            return p
        if p == "openai" and getattr(settings, "has_llm", False):
            return p
        if p == "say" and shutil.which("say"):
            return p
        if p == "mock":
            return p
    if getattr(settings, "elevenlabs_api_key", ""):
        return "elevenlabs"
    if getattr(settings, "has_llm", False) and (getattr(settings, "tts_provider", "") == "openai"):
        return "openai"
    if platform.system() == "Darwin" and shutil.which("say"):
        return "say"
    return "mock"


def synthesize(text: str, speaker: str, out_dir: Path, idx: int, settings) -> Tuple[Path, float]:
    out_dir.mkdir(parents=True, exist_ok=True)
    provider = _pick_provider(settings)
    wav = out_dir / f"voice{idx:02d}.wav"
    if provider == "elevenlabs":
        _elevenlabs(text, settings, wav)
    elif provider == "openai":
        _openai(text, speaker, settings, wav)
    elif provider == "say":
        _say(text, speaker, wav, out_dir, idx)
    else:
        _mock(text, wav)
    return wav, probe_duration(wav)


def provider_name(settings) -> str:
    return _pick_provider(settings)


# --------------------------------------------------------------------- providers
def _say(text: str, speaker: str, wav: Path, tmp: Path, idx: int) -> None:
    voice, rate = _SAY_VOICE.get(speaker, _SAY_VOICE["narrator"])
    aiff = tmp / f"raw{idx:02d}.aiff"
    run(["say", "-v", voice, "-r", str(rate), "-o", str(aiff), text])
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(aiff),
         "-af", _SOFT_AF, "-ar", "44100", "-ac", "2", str(wav)])
    aiff.unlink(missing_ok=True)


def _openai(text: str, speaker: str, settings, wav: Path) -> None:  # pragma: no cover - network
    from openai import OpenAI
    client = OpenAI(api_key=settings.openai_api_key)
    voice = getattr(settings, "tts_voice", "") or "onyx"
    mp3 = wav.with_suffix(".mp3")
    with client.audio.speech.with_streaming_response.create(
            model="tts-1-hd", voice=voice, input=text[:4000]) as resp:
        resp.stream_to_file(str(mp3))
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(mp3),
         "-ar", "44100", "-ac", "2", str(wav)])
    mp3.unlink(missing_ok=True)


def _elevenlabs(text: str, settings, wav: Path) -> None:  # pragma: no cover - network
    import requests
    voice_id = getattr(settings, "elevenlabs_voice_id", "") or _ELEVEN_DEFAULT
    r = requests.post(
        f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
        headers={"xi-api-key": settings.elevenlabs_api_key, "Content-Type": "application/json"},
        json={"text": text[:5000], "model_id": "eleven_multilingual_v2",
              "voice_settings": {"stability": 0.5, "similarity_boost": 0.75}}, timeout=90)
    r.raise_for_status()
    mp3 = wav.with_suffix(".mp3")
    mp3.write_bytes(r.content)
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(mp3),
         "-ar", "44100", "-ac", "2", str(wav)])
    mp3.unlink(missing_ok=True)


def _mock(text: str, wav: Path) -> None:
    seconds = max(1.5, len(text.split()) / 150 * 60)
    rate = 44100
    with wave.open(str(wav), "w") as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(b"\x00\x00\x00\x00" * int(seconds * rate))

