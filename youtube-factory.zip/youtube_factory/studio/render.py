"""Render: orchestrate storyboard -> narration -> footage -> finished video."""
from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Callable, Optional

import requests

from . import compose, footage, voice
from .ffmpeg_utils import has_ffmpeg, run
from .storyboard import Storyboard, build_storyboard

FPS = compose.FPS
XFADE = 0.4
LEAD_IN, TAIL = 0.45, 0.95
_TRANSITIONS = ["fade", "dissolve", "fadeblack", "fade", "dissolve",
                "fade", "fadeblack", "dissolve", "fade", "dissolve"]


def produce_video(topic: str, out_path: Optional[Path] = None, settings=None,
                  storyboard: Optional[Storyboard] = None,
                  log: Callable[[str], None] = print) -> Path:
    """Topic -> finished mp4. Returns the output path."""
    if not has_ffmpeg():
        raise RuntimeError("ffmpeg/ffprobe not found on PATH. Install ffmpeg first "
                           "(macOS: `brew install ffmpeg`).")
    from ..config import get_settings
    settings = settings or get_settings()

    sb = storyboard or build_storyboard(topic, settings, log=log)
    out_path = Path(out_path) if out_path else (settings.output_dir / "videos" /
                                                f"{_slug(sb.title)}.mp4")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cache_dir = settings.output_dir / "footage_cache"
    log(f"🎬 Producing “{sb.title}” — {len(sb.beats)} beats, voice={voice.provider_name(settings)}")

    sess = requests.Session()
    with tempfile.TemporaryDirectory() as tmpd:
        tmp = Path(tmpd)
        durs, narrations, srcs, pool = [], [], [], []

        # Pass 1: narration + footage per beat.
        for i, beat in enumerate(sb.beats):
            wav, ndur = voice.synthesize(beat.narration, beat.speaker, tmp, i, settings)
            narrations.append(wav)
            durs.append(LEAD_IN + ndur + TAIL)
            src = footage.fetch_clip(beat.queries, cache_dir, i, sess)
            srcs.append(src)
            if src and src not in pool:
                pool.append(src)
            log(f"   beat {i+1}/{len(sb.beats)} {'footage' if src else 'no-footage'} "
                f"· {durs[i]:.1f}s · “{beat.caption}”")

        # Pass 2: compose each clip (reuse real footage where a beat had none).
        clips = []
        title_idx = len(sb.beats) - 1
        for i, beat in enumerate(sb.beats):
            ov = tmp / f"ov{i:02d}.png"
            compose.make_overlay(beat.caption, ov, title=(i == title_idx))
            clip = tmp / f"clip{i:02d}.mp4"
            src = srcs[i]
            if src is None and pool:
                compose.make_clip(pool[i % len(pool)], ov, clip, durs[i],
                                  start=3.0 + (i * 2.5) % 8)
            elif src is not None:
                compose.make_clip(src, ov, clip, durs[i])
            else:
                compose.make_color_clip(ov, clip, durs[i])
            clips.append(clip)

        video = _edit_video(clips, durs, tmp, log)
        audio = _build_audio(narrations, durs, tmp)
        log("🎚  Mastering & muxing…")
        run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
             "-i", str(video), "-i", str(audio), "-c:v", "copy",
             "-c:a", "aac", "-b:a", "192k", "-shortest", str(out_path)])

    # Sidecar metadata (title/description/tags) for uploading later.
    try:
        from .metadata import build_metadata
        meta = build_metadata(sb)
        out_path.with_suffix(".metadata.json").write_text(
            meta.model_dump_json(indent=2), encoding="utf-8")
    except Exception:  # metadata is a nice-to-have, never fatal
        pass

    log(f"✅ {out_path}")
    return out_path


def _edit_video(clips, durs, tmp: Path, log) -> Path:
    n = len(clips)
    offsets, cum = [], 0.0
    for t in range(n - 1):
        cum += durs[t]
        offsets.append(round(cum - (t + 1) * XFADE, 3))
    total = round(sum(durs) - (n - 1) * XFADE, 3)

    vin = []
    for c in clips:
        vin += ["-i", str(c)]
    fc, prev = [], "0:v"
    for t in range(n - 1):
        lbl = f"x{t}"
        fc.append(f"[{prev}][{t+1}:v]xfade=transition={_TRANSITIONS[t % len(_TRANSITIONS)]}"
                  f":duration={XFADE}:offset={offsets[t]}[{lbl}]")
        prev = lbl
    fc.append(f"[{prev}]fade=t=in:st=0:d=0.5,fade=t=out:st={max(0.0, total-0.8):.2f}:d=0.8,"
              f"format=yuv420p[v]")
    out = tmp / "video.mp4"
    log("🎞  Editing (crossfades)…")
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *vin,
         "-filter_complex", ";".join(fc), "-map", "[v]",
         "-c:v", "libx264", "-preset", "slow", "-crf", "19",
         "-pix_fmt", "yuv420p", "-r", str(FPS), str(out)])
    return out


def _build_audio(narrations, durs, tmp: Path) -> Path:
    n = len(narrations)
    starts, cum = [0.0], 0.0
    for t in range(n - 1):
        cum += durs[t]
        starts.append(round(cum - (t + 1) * XFADE, 3))
    total = round(sum(durs) - (n - 1) * XFADE, 3)

    music = tmp / "music.wav"
    compose.render_music(total, music)
    ain = []
    for nf in narrations:
        ain += ["-i", str(nf)]
    ain += ["-i", str(music)]
    afc = []
    for i in range(n):
        delay = int(round((starts[i] + LEAD_IN) * 1000))
        afc.append(f"[{i}:a]adelay={delay}|{delay}[v{i}]")
    afc.append("".join(f"[v{i}]" for i in range(n)) +
               f"amix=inputs={n}:normalize=0:duration=longest[voice]")
    afc.append(f"[{n}:a]volume=0.12[mus]")
    afc.append("[voice][mus]amix=inputs=2:normalize=0:duration=longest,"
               "loudnorm=I=-16:TP=-1.5:LRA=11[aout]")
    audio = tmp / "audio.wav"
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *ain,
         "-filter_complex", ";".join(afc), "-map", "[aout]",
         "-t", f"{total:.3f}", "-ar", "44100", "-ac", "2", str(audio)])
    return audio


def _slug(text: str) -> str:
    import re
    s = re.sub(r"[^\w\s-]", "", text.lower()).strip()
    return re.sub(r"[\s_-]+", "-", s)[:60] or "video"

