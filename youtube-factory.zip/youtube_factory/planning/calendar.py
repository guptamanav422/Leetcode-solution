"""A simple JSON-backed content calendar that tracks videos across channels."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from ..models import PipelineStatus, VideoProject


class ContentCalendar:
    def __init__(self, store_path: str | Path = "output/calendar.json") -> None:
        self.store_path = Path(store_path)
        self._entries: List[dict] = []
        if self.store_path.exists():
            self._entries = json.loads(self.store_path.read_text(encoding="utf-8"))

    def _save(self) -> None:
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        self.store_path.write_text(
            json.dumps(self._entries, indent=2, default=str), encoding="utf-8"
        )

    def upsert(self, project: VideoProject) -> None:
        entry = json.loads(project.model_dump_json())
        for i, e in enumerate(self._entries):
            if e["channel_id"] == project.channel_id and e["slug"] == project.slug:
                self._entries[i] = entry
                self._save()
                return
        self._entries.append(entry)
        self._save()

    def all(self) -> List[dict]:
        return list(self._entries)

    def for_channel(self, channel_id: str) -> List[dict]:
        return [e for e in self._entries if e["channel_id"] == channel_id]

    def by_status(self, status: PipelineStatus) -> List[dict]:
        return [e for e in self._entries if e["status"] == status.value]

    def due_for_publish(self, now: Optional[datetime] = None) -> List[dict]:
        now = now or datetime.utcnow()
        out = []
        for e in self._entries:
            sched = e.get("scheduled_for")
            if e["status"] == PipelineStatus.READY.value and sched:
                if datetime.fromisoformat(str(sched).replace("Z", "")) <= now:
                    out.append(e)
        return out

    def summary(self) -> dict:
        counts: dict[str, int] = {}
        for e in self._entries:
            counts[e["status"]] = counts.get(e["status"], 0) + 1
        return {"total": len(self._entries), "by_status": counts}

