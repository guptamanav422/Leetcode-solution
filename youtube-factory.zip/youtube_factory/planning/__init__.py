"""Multi-channel content calendar (JSON-backed)."""

