"""Turn a channel's weekly cadence into concrete publish datetimes."""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import List

from ..models import ChannelConfig

_WEEKDAYS = {
    "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
    "friday": 4, "saturday": 5, "sunday": 6,
}


def _parse_time(value: str) -> tuple[int, int]:
    hh, mm = (value.split(":") + ["0"])[:2]
    return int(hh), int(mm)


def upcoming_slots(channel: ChannelConfig, count: int, start: datetime | None = None) -> List[datetime]:
    """Return the next `count` publish datetimes honoring upload_days/time + cadence."""
    start = start or datetime.now()
    hour, minute = _parse_time(channel.upload_time)
    target_days = [_WEEKDAYS[d.lower()] for d in channel.upload_days if d.lower() in _WEEKDAYS]
    if not target_days:
        target_days = [1, 4]  # Tue/Fri fallback
    target_days.sort()

    slots: List[datetime] = []
    day = start.replace(hour=hour, minute=minute, second=0, microsecond=0)
    # cap how many slots we use per week to the cadence
    per_week = max(1, min(channel.cadence_per_week, len(target_days)))
    allowed_days = target_days[:per_week]

    probe = day
    guard = 0
    while len(slots) < count and guard < 400:
        if probe.weekday() in allowed_days and probe > start:
            slots.append(probe)
        probe += timedelta(days=1)
        probe = probe.replace(hour=hour, minute=minute, second=0, microsecond=0)
        guard += 1
    return slots

