"""Upload a finished video to YouTube via the Data API v3.

Runs in DRY-RUN mode (prints the request) unless OAuth client secrets are present.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Optional

from ..config import get_settings
from ..models import VideoMetadata
from ..utils import logger

_SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]


def upload_video(
    video_path: str,
    metadata: VideoMetadata,
    thumbnail_path: Optional[str] = None,
    publish_at: Optional[datetime] = None,
) -> Optional[str]:
    settings = get_settings()
    if not settings.has_youtube or not video_path or not Path(video_path).exists():
        logger.info(
            "[DRY-RUN] Would upload '%s' (%s) -> title=%r, privacy=%s, publishAt=%s",
            video_path, "missing client secrets" if not settings.has_youtube else "ok",
            metadata.title, metadata.privacy_status, publish_at,
        )
        return None
    return _real_upload(video_path, metadata, thumbnail_path, publish_at)


def _get_service():  # pragma: no cover - requires OAuth + network
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build

    settings = get_settings()
    token_path = Path(settings.youtube_token_store)
    creds = None
    if token_path.exists():
        creds = Credentials.from_authorized_user_file(str(token_path), _SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                settings.youtube_client_secrets, _SCOPES
            )
            creds = flow.run_local_server(port=0)
        token_path.parent.mkdir(parents=True, exist_ok=True)
        token_path.write_text(creds.to_json(), encoding="utf-8")
    return build("youtube", "v3", credentials=creds)


def _real_upload(video_path, metadata, thumbnail_path, publish_at):  # pragma: no cover
    from googleapiclient.http import MediaFileUpload

    youtube = _get_service()
    status = {"privacyStatus": metadata.privacy_status, "selfDeclaredMadeForKids": False}
    if publish_at is not None:
        status["privacyStatus"] = "private"
        status["publishAt"] = publish_at.astimezone().isoformat()

    body = {
        "snippet": {
            "title": metadata.title,
            "description": metadata.description,
            "tags": metadata.tags,
            "categoryId": metadata.category_id,
        },
        "status": status,
    }
    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=MediaFileUpload(video_path, chunksize=-1, resumable=True),
    )
    response = None
    while response is None:
        _, response = request.next_chunk()
    video_id = response["id"]
    logger.info("Uploaded: https://youtu.be/%s", video_id)

    if thumbnail_path and Path(thumbnail_path).exists():
        youtube.thumbnails().set(
            videoId=video_id, media_body=MediaFileUpload(thumbnail_path)
        ).execute()
    return video_id

