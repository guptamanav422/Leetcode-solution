"""Orchestrator: idea -> studio-rendered video -> (optional) publish, per channel.

Renders real videos through `youtube_factory.studio`; the channel/calendar layer
adds ideation, scheduling, metadata, and publishing on top.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import List, Optional

from .config import ChannelConfig, get_settings
from .models import PipelineStatus, VideoProject
from .planning.calendar import ContentCalendar
from .publishing.scheduler import upcoming_slots
from .publishing.uploader import upload_video
from .steps import ideation, thumbnail
from .studio import build_metadata, build_storyboard, produce_video
from .utils import logger, slugify, write_json


def _project_dir(channel: ChannelConfig, slug: str) -> Path:
    return get_settings().output_dir / channel.id / slug


def plan_channel(channel: ChannelConfig, count: int, calendar: ContentCalendar) -> List[VideoProject]:
    """Generate ideas and reserve schedule slots, persisting them to the calendar."""
    ideas = ideation.generate_ideas(channel, count)
    slots = upcoming_slots(channel, count)
    projects: List[VideoProject] = []
    for idea, slot in zip(ideas, slots):
        slug = slugify(idea.title)
        project = VideoProject(
            channel_id=channel.id, slug=slug, idea=idea,
            status=PipelineStatus.PLANNED, scheduled_for=slot,
        )
        calendar.upsert(project)
        projects.append(project)
        logger.info("[%s] Planned '%s' for %s", channel.id, idea.title, slot)
    return projects


def produce(channel: ChannelConfig, project: VideoProject, calendar: ContentCalendar) -> VideoProject:
    """Render the idea into a finished video via the studio + build metadata."""
    out_dir = _project_dir(channel, project.slug)
    out_dir.mkdir(parents=True, exist_ok=True)

    topic = project.idea.title
    storyboard = build_storyboard(topic)
    video_path = produce_video(
        topic, out_path=out_dir / "video.mp4", storyboard=storyboard,
        log=lambda m: logger.info("%s", m))

    project.video_path = str(video_path)
    project.metadata = build_metadata(storyboard, channel)
    write_json(out_dir / "metadata.json", project.metadata)
    project.thumbnail_path = thumbnail.make_thumbnail(channel, project.idea, out_dir)

    project.status = PipelineStatus.READY
    project.updated_at = datetime.utcnow()
    calendar.upsert(project)
    write_json(out_dir / "project.json", project)
    logger.info("[%s] READY: %s", channel.id, project.idea.title)
    return project


def publish(project: VideoProject, calendar: ContentCalendar) -> VideoProject:
    if project.metadata is None:
        raise ValueError("Project has no metadata; run `produce` first.")
    video_id = upload_video(
        video_path=project.video_path or "",
        metadata=project.metadata,
        thumbnail_path=project.thumbnail_path,
        publish_at=project.scheduled_for,
    )
    if video_id:
        project.youtube_video_id = video_id
        project.status = PipelineStatus.PUBLISHED
    project.updated_at = datetime.utcnow()
    calendar.upsert(project)
    return project


def run_full(
    channel: ChannelConfig,
    count: int = 1,
    do_publish: bool = False,
    calendar: Optional[ContentCalendar] = None,
) -> List[VideoProject]:
    """Plan -> produce (-> publish) for `count` videos on a channel."""
    calendar = calendar or ContentCalendar(get_settings().output_dir / "calendar.json")
    projects = plan_channel(channel, count, calendar)
    finished: List[VideoProject] = []
    for project in projects:
        produced = produce(channel, project, calendar)
        if do_publish:
            produced = publish(produced, calendar)
        finished.append(produced)
    return finished

