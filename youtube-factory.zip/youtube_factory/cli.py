"""Command-line interface for the YouTube Factory."""
from __future__ import annotations

import click

from . import pipeline
from .config import get_channel, get_settings, load_channels
from .planning.calendar import ContentCalendar
from .publishing.scheduler import upcoming_slots
from .steps import ideation
from .utils import setup_logging


def _calendar() -> ContentCalendar:
    return ContentCalendar(get_settings().output_dir / "calendar.json")


@click.group()
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging.")
def cli(verbose: bool) -> None:
    """AI-assisted long-form YouTube content factory."""
    setup_logging(verbose)


@cli.command("channels")
def channels_cmd() -> None:
    """List configured channels."""
    for c in load_channels():
        click.echo(f"- {c.id:16} {c.name}  ({c.cadence_per_week}/wk, ~{c.target_minutes}min)")


@cli.command("ideas")
@click.argument("channel_id")
@click.option("-n", "--count", default=5, show_default=True)
def ideas_cmd(channel_id: str, count: int) -> None:
    """Generate video ideas for a channel."""
    channel = get_channel(channel_id)
    for i, idea in enumerate(ideation.generate_ideas(channel, count), 1):
        click.echo(f"{i}. {idea.title}\n   hook: {idea.hook}\n")


@cli.command("schedule")
@click.argument("channel_id")
@click.option("-n", "--count", default=4, show_default=True)
def schedule_cmd(channel_id: str, count: int) -> None:
    """Preview upcoming publish slots for a channel."""
    channel = get_channel(channel_id)
    for slot in upcoming_slots(channel, count):
        click.echo(slot.strftime("%a %Y-%m-%d %H:%M"))


@cli.command("plan")
@click.argument("channel_id")
@click.option("-n", "--count", default=3, show_default=True)
def plan_cmd(channel_id: str, count: int) -> None:
    """Generate ideas and reserve calendar slots."""
    channel = get_channel(channel_id)
    pipeline.plan_channel(channel, count, _calendar())


@cli.command("run")
@click.argument("channel_id")
@click.option("-n", "--count", default=1, show_default=True, help="Videos to produce.")
@click.option("--publish", is_flag=True, help="Also upload (dry-run without YouTube creds).")
def run_cmd(channel_id: str, count: int, publish: bool) -> None:
    """Plan -> produce (-> publish) full pipeline for a channel."""
    channel = get_channel(channel_id)
    projects = pipeline.run_full(channel, count=count, do_publish=publish, calendar=_calendar())
    for p in projects:
        click.echo(f"✔ {p.status.value:10} {p.idea.title}")
        if p.video_path:
            click.echo(f"   video: {p.video_path}")


@cli.command("status")
def status_cmd() -> None:
    """Show the content calendar summary."""
    cal = _calendar()
    summary = cal.summary()
    click.echo(f"Total videos: {summary['total']}")
    for status, n in sorted(summary["by_status"].items()):
        click.echo(f"  {status:10} {n}")


@cli.command("publish-due")
def publish_due_cmd() -> None:
    """Publish all READY videos whose scheduled time has passed."""
    cal = _calendar()
    from .models import VideoProject

    due = cal.due_for_publish()
    if not due:
        click.echo("Nothing due.")
        return
    for entry in due:
        pipeline.publish(VideoProject(**entry), cal)
        click.echo(f"Published-or-dry-ran: {entry['slug']}")


@cli.command("make")
@click.argument("topic")
@click.option("-o", "--out", default=None, help="Output .mp4 path.")
def make_cmd(topic: str, out: str | None) -> None:
    """Produce a finished narrated, real-footage video from a TOPIC.

    Example: python -m youtube_factory make "How Kodak missed digital photography"
    """
    from .studio import produce_video
    path = produce_video(topic, out_path=out, log=click.echo)
    click.echo(f"\nDone -> {path}")


if __name__ == "__main__":
    cli()

