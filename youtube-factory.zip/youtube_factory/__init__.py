"""YouTube Factory: an AI-assisted long-form video content pipeline."""

__version__ = "0.1.0"

