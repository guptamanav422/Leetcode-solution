"""Pydantic data models shared across the pipeline."""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class ChannelConfig(BaseModel):
    """A single YouTube channel's identity and publishing cadence."""

    id: str
    name: str
    niche: str
    persona: str = "a clear, engaging narrator"
    tone: str = "informative and engaging"
    target_minutes: int = 10
    cadence_per_week: int = Field(default=2, ge=1, le=7)
    upload_days: List[str] = Field(default_factory=lambda: ["Tuesday", "Friday"])
    upload_time: str = "16:00"
    voice: str = "onyx"
    visual_style: str = "clean, cinematic"
    keywords_seed: List[str] = Field(default_factory=list)

    @property
    def target_words(self) -> int:
        """~150 spoken words per minute."""
        return self.target_minutes * 150


class VideoIdea(BaseModel):
    title: str
    angle: str
    hook: str
    target_keywords: List[str] = Field(default_factory=list)


class ScriptSection(BaseModel):
    heading: str
    narration: str
    b_roll_keywords: List[str] = Field(default_factory=list)
    on_screen_text: Optional[str] = None

    @property
    def word_count(self) -> int:
        return len(self.narration.split())


class Script(BaseModel):
    title: str
    hook: str
    sections: List[ScriptSection]
    call_to_action: str = "If this story surprised you, subscribe for a new case study every week."

    @property
    def full_narration(self) -> str:
        parts = [self.hook] + [s.narration for s in self.sections] + [self.call_to_action]
        return "\n\n".join(p.strip() for p in parts if p.strip())

    @property
    def word_count(self) -> int:
        return len(self.full_narration.split())

    @property
    def estimated_seconds(self) -> float:
        return self.word_count / 150 * 60


class VideoMetadata(BaseModel):
    title: str
    description: str
    tags: List[str] = Field(default_factory=list)
    category_id: str = "27"  # Education
    privacy_status: str = "private"  # private | unlisted | public


class PipelineStatus(str, Enum):
    PLANNED = "planned"
    SCRIPTED = "scripted"
    VOICED = "voiced"
    ASSEMBLED = "assembled"
    READY = "ready"
    PUBLISHED = "published"
    FAILED = "failed"


class VideoProject(BaseModel):
    """One video moving through the pipeline; persisted as project.json."""

    channel_id: str
    slug: str
    idea: VideoIdea
    status: PipelineStatus = PipelineStatus.PLANNED
    script: Optional[Script] = None
    metadata: Optional[VideoMetadata] = None
    audio_path: Optional[str] = None
    visual_paths: List[str] = Field(default_factory=list)
    video_path: Optional[str] = None
    thumbnail_path: Optional[str] = None
    scheduled_for: Optional[datetime] = None
    youtube_video_id: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

