"""Step 1 — Ideation: turn a channel concept into concrete video ideas."""
from __future__ import annotations

import random
from typing import List

from ..models import ChannelConfig, VideoIdea
from ..utils import get_llm, logger

_MOCK_SUBJECTS = [
    "a household-name retailer", "a $10B startup", "a beloved airline",
    "a crypto exchange", "a fast-fashion empire", "a streaming pioneer",
    "a smartphone challenger", "a meal-kit unicorn", "a co-working giant",
]
_MOCK_REASONS = [
    "overexpansion", "a single fatal decision", "ignoring its core customers",
    "an accounting scandal", "a missed technology shift", "founder hubris",
    "burning cash with no path to profit",
]


def generate_ideas(channel: ChannelConfig, count: int = 5) -> List[VideoIdea]:
    """Return `count` video ideas, via LLM when available, else deterministic mock."""
    llm = get_llm()
    if llm is not None:
        return _ideas_via_llm(llm, channel, count)
    logger.info("Ideation in MOCK mode (no OPENAI_API_KEY).")
    return _ideas_mock(channel, count)


def _ideas_via_llm(llm, channel: ChannelConfig, count: int) -> List[VideoIdea]:
    system = (
        "You are a YouTube content strategist who designs high-retention, "
        "factual long-form video ideas. Always return valid JSON."
    )
    prompt = (
        f"Channel: {channel.name}\nNiche: {channel.niche}\nTone: {channel.tone}\n"
        f"Seed keywords: {', '.join(channel.keywords_seed)}\n\n"
        f"Propose {count} distinct video ideas. Return JSON of the form: "
        '{"ideas": [{"title": str, "angle": str, "hook": str, '
        '"target_keywords": [str, ...]}]}. '
        "Titles must be specific, curiosity-driven, and under 70 characters."
    )
    data = llm.complete_json(system, prompt)
    return [VideoIdea(**i) for i in data.get("ideas", [])][:count]


def _ideas_mock(channel: ChannelConfig, count: int) -> List[VideoIdea]:
    rng = random.Random(f"{channel.id}")
    ideas: List[VideoIdea] = []
    subjects = rng.sample(_MOCK_SUBJECTS, k=min(count, len(_MOCK_SUBJECTS)))
    for subject in subjects:
        reason = rng.choice(_MOCK_REASONS)
        title = f"How {subject.title()} Collapsed Because of {reason.title()}"
        ideas.append(
            VideoIdea(
                title=title[:70],
                angle=f"A {channel.tone} breakdown of how {subject} fell apart due to {reason}.",
                hook=f"In just 18 months, {subject} went from industry darling to cautionary tale. Here's exactly what went wrong.",
                target_keywords=channel.keywords_seed[:3] + [reason.replace(" ", "-")],
            )
        )
    return ideas

