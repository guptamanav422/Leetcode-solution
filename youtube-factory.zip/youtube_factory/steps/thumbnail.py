"""Step 5 — Thumbnail: render a 1280x720 click-optimized thumbnail."""
from __future__ import annotations

import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from ..models import ChannelConfig, VideoIdea

_W, _H = 1280, 720


def _font(size: int) -> ImageFont.FreeTypeFont:
    for name in ("Arial Bold.ttf", "Helvetica.ttc", "DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def make_thumbnail(channel: ChannelConfig, idea: VideoIdea, out_dir: Path) -> str:
    out = out_dir / "thumbnail.png"
    img = Image.new("RGB", (_W, _H), (8, 10, 16))
    draw = ImageDraw.Draw(img)

    # accent bar
    draw.rectangle([0, 0, 22, _H], fill=(220, 38, 38))

    # punchy short text derived from the title
    punch = idea.title.upper()
    for kw in ("HOW ", "WHY ", "THE STORY OF "):
        if punch.startswith(kw):
            punch = punch[len(kw):]
    words = punch.split()
    punch = " ".join(words[:6])

    font = _font(110)
    lines = textwrap.wrap(punch, width=14)[:3]
    y = (_H - len(lines) * 130) // 2
    for line in lines:
        # shadow for readability
        draw.text((64 + 4, y + 4), line, font=font, fill=(0, 0, 0))
        draw.text((64, y), line, font=font, fill=(255, 215, 0))
        y += 130

    badge_font = _font(40)
    draw.text((64, _H - 90), channel.name.upper(), font=badge_font, fill=(180, 190, 210))

    img.save(out)
    return str(out)

